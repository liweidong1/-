//
//  ViewController.m
//  Recorder
//
//  Created by yingxin on 16/7/25.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "ViewController.h"

@import AVKit;
@import AVFoundation;

@interface ViewController ()
@property (nonatomic) NSString *docPath;
@property (nonatomic) NSArray *dataList;
@end

@implementation ViewController
- (NSString *)docPath{
    if (!_docPath) {
        _docPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    }
    return _docPath;
}
+ (instancetype)shareInstance{
    //线程安全的单例
    static ViewController *vc = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        //此处方法每次程序运行期间 只会进行一次. 就算多个线程访问也没问题.
        vc = [ViewController new];
    });
    return vc;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"音频列表";
    //self.view.backgroundColor = [UIColor randomColor];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            _dataList = [[NSFileManager defaultManager] subpathsAtPath:self.docPath];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];
                [self.tableView.mj_header endRefreshing];
            });
        });
    }];
    [self.tableView.mj_header beginRefreshing];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    cell.textLabel.text = _dataList[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    AVPlayerViewController *vc = [AVPlayerViewController new];
    NSString *path = [_docPath stringByAppendingPathComponent:_dataList[indexPath.row]];
    vc.player = [AVPlayer playerWithURL:[NSURL fileURLWithPath:path]];
    [vc.player play];
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
