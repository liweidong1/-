//
//  UIColor+Extra.h
//  Recorder
//
//  Created by tarena on 16/7/25.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (Extra)
+ (UIColor *)randomColor;
@end










