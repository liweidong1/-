//
//  LeftMenuViewController.h
//  Recorder
//
//  Created by tarena on 16/7/25.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftMenuViewController : UIViewController

@end
