//
//  AppDelegate.h
//  Recorder
//
//  Created by yingxin on 16/7/25.
//  Copyright © 2016年 yingxin. All rights reserved.
//



@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

